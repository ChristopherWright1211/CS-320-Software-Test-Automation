package taskservice;

public class Task {

    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {

        // taskId: not null, not empty, max 10 chars
        if (taskId == null || taskId.isEmpty() || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        // name: not null, not empty, max 20 chars
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }

        // description: not null, not empty, max 50 chars
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }
        this.description = description;
    }
}
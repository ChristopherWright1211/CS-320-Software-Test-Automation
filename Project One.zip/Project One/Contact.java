package contact;

import java.util.Objects;

public final class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;   // exactly 10 digits
    private String address; // <= 30 chars

    public Contact(String contactId, String firstName, String lastName,
                   String phone, String address) {
        validateId(contactId);
        this.contactId = contactId;

        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    private static void validateId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("contactId must be non-null and <= 10 chars");
        }
    }

    private static void requireNonNullLen(String value, int maxLen, String field) {
        if (value == null) {
            throw new IllegalArgumentException(field + " cannot be null");
        }
        if (value.length() > maxLen) {
            throw new IllegalArgumentException(field + " must be <= " + maxLen + " chars");
        }
    }

    private static void requirePhone10(String value) {
        if (value == null) {
            throw new IllegalArgumentException("phone cannot be null");
        }
        if (!value.matches("\\d{10}")) {
            throw new IllegalArgumentException("phone must be exactly 10 digits");
        }
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        requireNonNullLen(firstName, 10, "firstName");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        requireNonNullLen(lastName, 10, "lastName");
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        requirePhone10(phone);
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        requireNonNullLen(address, 30, "address");
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;
        Contact contact = (Contact) o;
        return contactId.equals(contact.contactId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId);
    }
}
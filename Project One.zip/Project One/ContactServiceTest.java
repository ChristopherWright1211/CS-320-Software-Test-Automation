package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void addRejectsDuplicateIds() {
        ContactService svc = new ContactService();
        Contact a = new Contact("X1", "Amy", "Lee", "1111111111", "A");
        Contact b = new Contact("X1", "Bob", "Kay", "2222222222", "B");
        svc.addContact(a);
        assertThrows(IllegalStateException.class, () -> svc.addContact(b));
    }

    @Test
    void deleteRemovesExistingOrThrows() {
        ContactService svc = new ContactService();
        Contact a = new Contact("A1", "Amy", "Lee", "1111111111", "A");
        svc.addContact(a);
        svc.deleteContact("A1");
        assertThrows(java.util.NoSuchElementException.class, () -> svc.get("A1"));
        assertThrows(java.util.NoSuchElementException.class, () -> svc.deleteContact("A1"));
    }

    @Test
    void updateFieldsById() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("C1", "Amy", "Lee", "1111111111", "Addr"));

        svc.updateFirstName("C1", "Zoe");
        svc.updateLastName("C1", "Z");
        svc.updatePhone("C1", "9999999999");
        svc.updateAddress("C1", "123 Long Road");

        Contact c = svc.get("C1");
        assertAll(
            () -> assertEquals("Zoe", c.getFirstName()),
            () -> assertEquals("Z", c.getLastName()),
            () -> assertEquals("9999999999", c.getPhone()),
            () -> assertEquals("123 Long Road", c.getAddress())
        );
    }

    @Test
    void updateValidationsStillApply() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("C2", "Amy", "Lee", "1111111111", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> svc.updatePhone("C2", "123"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("C2", null));
    }
}
package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void ctorAndGettersWork() {
        Contact c = new Contact("ID123", "Alice", "Smith",
                "1234567890", "1 Main Street");
        assertEquals("ID123", c.getContactId());
        assertEquals("Alice", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("1 Main Street", c.getAddress());
    }

    @Test
    void idIsRequiredMax10AndNotUpdatable() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "A", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("01234567890", "A", "B", "1234567890", "Addr")); // 11 chars
        Contact c = new Contact("ID", "A", "B", "1234567890", "Addr");
        assertEquals("ID", c.getContactId()); // no setter exists
    }

    @Test
    void namesRequiredMax10() {
        Contact c = new Contact("ID", "A", "B", "1234567890", "Addr");
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("ABCDEFGHIJK"));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("ABCDEFGHIJK"));
    }

    @Test
    void phoneExactly10Digits() {
        Contact c = new Contact("ID", "A", "B", "1234567890", "Addr");
        assertThrows(IllegalArgumentException.class, () -> c.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123456789"));    // 9
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("12345678901"));  // 11
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123-456-7890")); // bad format

        c.setPhone("0987654321");
        assertEquals("0987654321", c.getPhone());
    }

    @Test
    void addressRequiredMax30() {
        Contact c = new Contact("ID", "A", "B", "1234567890", "Addr");
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
        assertThrows(IllegalArgumentException.class,
                () -> c.setAddress("0123456789012345678901234567891")); // 31
        c.setAddress("012345678901234567890123456789"); // 30 ok
        assertEquals(30, c.getAddress().length());
    }
}
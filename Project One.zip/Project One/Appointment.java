package com.appointment;

import java.util.Date;

public class Appointment {

    // Required fields
    private final String appointmentId;  // not null, max length 10, not updatable
    private Date appointmentDate;        // not null, cannot be in the past
    private String description;          // not null, max length 50

    // Constructor with validation
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // Validate appointmentId
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // Validate appointmentDate (not null and not in the past)
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // Validate description
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getters (no setter for ID so it cannot be updated)
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    // Optional: setters for date and description with same validation rules.
    // Your milestone only *requires* the fields and constructor + getters,
    // but if you want to support updates, you can uncomment these:

    /*
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
    */
}
package taskservice.test;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import taskservice.Task;
import taskservice.TaskService;

public class TaskServiceTest {

    private TaskService taskService;

    @Before
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTaskWithUniqueId() {
        taskService.addTask("1", "Name1", "Description1");
        Task task = taskService.getTask("1");
        assertNotNull(task);
        assertEquals("Name1", task.getName());
        assertEquals("Description1", task.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddTaskWithDuplicateIdThrowsException() {
        taskService.addTask("1", "Name1", "Description1");
        taskService.addTask("1", "Another", "Another desc");
    }

    @Test
    public void testDeleteTaskById() {
        taskService.addTask("1", "Name1", "Description1");
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonexistentTaskThrowsException() {
        taskService.deleteTask("999");
    }

    @Test
    public void testUpdateTaskNameById() {
        taskService.addTask("1", "Name1", "Description1");
        taskService.updateTaskName("1", "Updated Name");
        assertEquals("Updated Name", taskService.getTask("1").getName());
    }

    @Test
    public void testUpdateTaskDescriptionById() {
        taskService.addTask("1", "Name1", "Description1");
        taskService.updateTaskDescription("1", "Updated Description");
        assertEquals("Updated Description", taskService.getTask("1").getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateNameOfNonexistentTaskThrowsException() {
        taskService.updateTaskName("999", "Name");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateDescriptionOfNonexistentTaskThrowsException() {
        taskService.updateTaskDescription("999", "Description");
    }
}
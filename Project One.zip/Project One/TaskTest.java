package taskservice.test;

import static org.junit.Assert.*;
import org.junit.Test;

import taskservice.Task;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("12345", "Test Name", "This is a description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Name", task.getName());
        assertEquals("This is a description.", task.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTaskIdCannotBeNull() {
        new Task(null, "Name", "Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTaskIdTooLong() {
        new Task("12345678901", "Name", "Description"); // 11 chars
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNameCannotBeNull() {
        new Task("123", null, "Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNameTooLong() {
        new Task("123", "This name is more than twenty chars", "Description");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionCannotBeNull() {
        new Task("123", "Name", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionTooLong() {
        new Task("123", "Name",
            "This description is going to be more than fifty characters long to fail.");
    }

    @Test
    public void testTaskIdIsNotUpdatable() {
        Task task = new Task("12345", "Name", "Description");
        task.setName("New Name");
        task.setDescription("New Description");

        assertEquals("12345", task.getTaskId());
        assertEquals("New Name", task.getName());
        assertEquals("New Description", task.getDescription());
    }
}
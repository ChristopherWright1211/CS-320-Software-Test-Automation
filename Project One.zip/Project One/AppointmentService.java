package com.appointment;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    // Store appointments in a Map keyed by appointmentId
    private Map<String, Appointment> appointments;

    public AppointmentService() {
        this.appointments = new HashMap<>();
    }

    // Add a new appointment (enforce unique ID)
    public void addAppointment(String appointmentId, Date appointmentDate, String description) {
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }

        Appointment newAppointment = new Appointment(appointmentId, appointmentDate, description);
        appointments.put(appointmentId, newAppointment);
    }

    // Delete an existing appointment by ID
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }
        appointments.remove(appointmentId);
    }

    // Optional helper for tests or debugging
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
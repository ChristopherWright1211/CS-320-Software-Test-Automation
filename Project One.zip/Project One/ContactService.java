package contact;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("contact cannot be null");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalStateException("Duplicate contactId: " + id);
        }
        contacts.put(id, contact);
    }

    public void deleteContact(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId cannot be null");
        }
        if (contacts.remove(contactId) == null) {
            throw new NoSuchElementException("No contact with id: " + contactId);
        }
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact c = find(contactId);
        c.setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        Contact c = find(contactId);
        c.setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        Contact c = find(contactId);
        c.setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        Contact c = find(contactId);
        c.setAddress(address);
    }

    public Contact get(String contactId) {
        return find(contactId);
    }

    private Contact find(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId cannot be null");
        }
        Contact c = contacts.get(contactId);
        if (c == null) {
            throw new NoSuchElementException("No contact with id: " + contactId);
        }
        return c;
    }
}
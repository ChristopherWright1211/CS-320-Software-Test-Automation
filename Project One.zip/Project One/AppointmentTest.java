package com.appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    // Helper method: return a date in the future (tomorrow)
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTime();
    }

    // Helper method: return a date in the past (yesterday)
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        return cal.getTime();
    }

    @Test
    public void testValidAppointment() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("12345", futureDate, "Regular checkup");

        assertEquals("12345", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Regular checkup", appt.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Description");
        });
    }

    @Test
    public void testAppointmentIdNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });
    }

    @Test
    public void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Description");
        });
    }

    @Test
    public void testAppointmentDateInPast() {
        Date pastDate = getPastDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Description");
        });
    }

    @Test
    public void testDescriptionNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Date futureDate = getFutureDate();
        String longDescription = "This description is definitely more than fifty characters long!";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, longDescription);
        });
    }
}
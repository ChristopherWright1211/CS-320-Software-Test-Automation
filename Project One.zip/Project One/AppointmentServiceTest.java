package com.appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
    }

    // Helper method: future date (tomorrow)
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTime();
    }

    @Test
    public void testAddAppointmentSuccessfully() {
        service.addAppointment("1", getFutureDate(), "Dentist");

        Appointment appt = service.getAppointment("1");
        assertNotNull(appt);
        assertEquals("1", appt.getAppointmentId());
        assertEquals("Dentist", appt.getDescription());
    }

    @Test
    public void testAddMultipleAppointmentsWithDifferentIds() {
        service.addAppointment("1", getFutureDate(), "Dentist");
        service.addAppointment("2", getFutureDate(), "Doctor");

        assertNotNull(service.getAppointment("1"));
        assertNotNull(service.getAppointment("2"));
    }

    @Test
    public void testAddAppointmentWithDuplicateIdThrowsException() {
        service.addAppointment("1", getFutureDate(), "Dentist");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("1", getFutureDate(), "Doctor");
        });
    }

    @Test
    public void testDeleteExistingAppointment() {
        service.addAppointment("1", getFutureDate(), "Dentist");
        service.deleteAppointment("1");

        assertNull(service.getAppointment("1"));
    }

    @Test
    public void testDeleteNonExistingAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}